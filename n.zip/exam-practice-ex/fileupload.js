//models/
tokens: [{
    token: {
        type: String
    }
}]
// source_id: {
//     type: mongoose.Schema.Types.ObjectId,
//     ref: "User"
// },


// Generate Token //
userSchema.methods.generate = async function() {
try {
    const token = jwt.sign({ _id: this._id.toString() }, process.env.TOKEN_KEY);
    this.tokens = this.tokens.concat({ token: token });
    await this.save();
    return token;
} catch (error) {
    return res.status(status.INTERNAL_SERVER_ERROR).json(new APIResponse("Token Not Generated", true, 400, error.message))
}
}

// Password Bcrypt //
userSchema.pre("save", async function(next) {
    if (this.isModified("password")) {
        this.password = await bcrypt.hash(this.password, 10);
    }
    next();
});


// // Verify Token //
exports.verifyToken = async (req, res, next) => {
    try {
        let data = {time: Date()};
        const token = jwt.sign(data,process.env.TOKEN_KEY);
        console.log(token);
        const verifyToken = jwt.verify(token, process.env.TOKEN_KEY);
        // // console.log(verifyToken);
        // const User = await userData.findOne({ _id: verifyToken._id });
        
        req.token = token;
        // req.User = User;  
        next();
    } catch (error) {
        return res.status(400).json({message:"Pleas Login"})
    }
};

const multer = require("multer");

// set storage engine//
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, "./src/public/image");
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + file.originalname);
    }
})

exports.upload = multer({
    storage: storage,
    limits: { fileSize: 6000000 },
    fileFilter: (req, file, cb) => {
        if (file.mimetype == "image/jpg" || file.mimetype == "image/jpeg" || file.mimetype == "image/png") {
            cb(null, true)
        } else {
            cb(null, true)
            return cb(new Error('Only JPG,JPEG and PNG File Is Aloud'));
        }
    }
}).single('image');

// User Login //
exports.userLogin = async (req, res) => {
    try {
        username = req.body.username;
        password = req.body.password;

        const data = await userData.findOne({ username });
        console.log("🚀 ~ file: user.controller.js ~ line 73 ~ exports.userLogin= ~ userData", data)
        
        const match = await bcrypt.compare(password, data.password);
        if (!data.tokens[0]) {
            const token = await data.generate();
        }
        if (match && username === data.username) {
            return res.status(200).json({
                message: "User Login Successfully",
                status: 200,
                id: data._id,
                token: data.tokens[0].token,
            });
        } else {
            return res
                .status(status.INTERNAL_SERVER_ERROR)
                .json(new APIResponse("Enter Valid Username Or Password", true, 400));
        }
    } catch (error) {
        return res
            .status(status.INTERNAL_SERVER_ERROR)
            .json(new APIResponse("User Not Login", true, 400, error.message));
    }
};

exports.userRegister = (req, res) => {
    try {
        const data = new userData(req.body);
        email = req.body.email;
        username = req.body.username;

        if (!validator.isEmail(req.body.email)) {
            return res.json({
                message: "Please Give Email In Propper Formate",
            });
        } else {
            if (email) {
                userData.findOne({ email: email }).then((useremail) => {
                    if (useremail) {
                        return res
                            .status(status.INTERNAL_SERVER_ERROR)
                            .json(new APIResponse("Email Is Already Save", true, 208));
                    } else {
                        if (username) {
                            userData.findOne({ username: username }).then((usern) => {
                                if (usern) {
                                    return res
                                        .status(status.INTERNAL_SERVER_ERROR)
                                        .json(new APIResponse("Username Is Already Save", true, 208));
                                } else {
                                    data.save();
                                    return res
                                        .status(status.OK)
                                        .json(
                                            new APIResponse("User Register Successfully", false, 200, data)
                                        );
                                }
                            });
                        }
                    }
                });
            } else {
                return res
                    .status(status.INTERNAL_SERVER_ERROR)
                    .json(new APIResponse("Email Is Undefined", true, 404));
            }
        }
    } catch (error) {
        return res
            .status(status.INTERNAL_SERVER_ERROR)
            .json(new APIResponse("User Data Is Not Save", true, 400, error.message));
    }
};