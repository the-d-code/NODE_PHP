<?php

$conn = mysqli_connect("localhost","root","root","myexamdb")
or die("Connection failed");

//echo  "Connection successfull";

?>