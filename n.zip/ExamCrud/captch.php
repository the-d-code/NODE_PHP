<?php

$_SESSION['code'] = rand(1, 50000);

$im = @imagecreate(250, 30) or die("Can nor create image");

$background_color = imagecolorallocate($im, 255, 255, 255);
$text_color = imagecolorallocate($im, 255, 14, 91);

imagestring($im, 5, 5, 5, $_SESSION['code'], $text_color);

header("Content-type: image/png");
imagepng($im);
imagedestroy($im);
?>