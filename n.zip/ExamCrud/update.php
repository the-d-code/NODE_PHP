<?php
include('config.php'); 

if ($_SERVER['REQUEST_METHOD'] === 'POST'){

    $id=$_POST['id'];
    $name=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['password'];

    $target_file = "uploads/".basename($_FILES['image']['name']);
    move_uploaded_file($_FILES['image']['tmp_name'],$target_file);

    $hashed_password = password_hash($password, PASSWORD_BCRYPT);
    $insertsql = "UPDATE `user` SET `name` = '$name', `email` = '$email', `password` = '$hashed_password', `image` = '$target_file' WHERE `user`.`id` = $id";
    $result = $conn->query($insertsql);

   
    if($result){
        header("Location:home.php");
    }
    else{
        $error_message = "Not inserted";
    }
}
   
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $squery ="select * from user WHERE id=$id";
    $result=$conn->query($squery);

    $row=$result->fetch_assoc();
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="post" enctype="multipart/form-data">

        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        <label for="name">Name:</label>
        <input type="text" name="name" value="<?php echo $row['name']?>"/></br>
        <label for="name">Email:</label>
        <input type="text" name="email" value="<?php echo $row['email']?>"/></br>
        <label for="name">Password:</label>
        <input type="text" name="password" value="<?php echo $row['password']?>"/></br>
        <input type="file" name="image">

        <button type="submit">Submit</button>

    </form>
</body>
</html>