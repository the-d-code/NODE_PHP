<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User List</title>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</head>
<body>

<h1>User List</h1>

<ul id="userList"></ul>

<script>
$(document).ready(function() {
    // Make an AJAX request to fetch user data
    $.ajax({
        url: 'http://localhost:8080/student/getdata', // Adjust the URL based on your server
        method: 'GET',
        dataType: 'json',
        success: function(data) {
            // Access the 'users' property before iterating over it
            var users = data.users;
            displayUserList(users);
        },
        error: function(error) {
            console.error('Error fetching user data:', error);
        }
    });

    // Function to display the user list
    function displayUserList(users) {
        var userListElement = $('#userList');
        
        // Clear existing content
        userListElement.empty();

        // Iterate through the users and append them to the list
        users.forEach(function(user) {
            var listItem = $('<li>').text('Name: ' + user.name + ' - Email: ' + user.email);
            userListElement.append(listItem);
        });
    }
});
</script>

</body>
</html>
