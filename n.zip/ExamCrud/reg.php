<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $target_file = "uploads/" . basename($_FILES['image']['name']);
    move_uploaded_file($_FILES['image']['tmp_name'], $target_file);

    $hashed_password = password_hash($password, PASSWORD_BCRYPT);
    $insertsql = "INSERT INTO `user` (`name`, `email`, `password`,`image`) VALUES ('$name','$email','$hashed_password','$target_file')";
    $result = $conn->query($insertsql);


    if ($result) {
        header("Location:home.php");
    } else {
        $error_message = "Not inserted";
    }
}


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <form method="post" enctype="multipart/form-data">

        <label for="name">Name:</label>
        <input type="text" name="name" /></br>
        <label for="name">Email:</label>
        <input type="text" name="email" /></br>
        <label for="name">Password:</label>
        <input type="text" name="password" /></br>
        <input type="file" name="image"></br>
        <label for="captcha">CAPTCHA:</label>
        <input type="text" id="captcha" name="captcha" required>
        <div class="captcha">
            <img src="captch.php" alt="CAPTCHA">

            <button type="submit">Submit</button>

    </form>
</body>

</html>