<?php
include('config.php');?>

<?php

    if(isset($_GET['id'])){
        $id=$_GET['id'];
        $dquery=" DELETE FROM user WHERE `user`.`id` = $id";
        $result=$conn->query($dquery);
        if($result){
            header('location:home.php');
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
        <tr>
        <th>Name</th>
        <th>Email</th>
        <th>Password</th>
        <th>Image</th>
        <th>Update</th>
        <th>Delete</th>
        </tr>

        <?php
        
            $query="select * from user";
            $result=$conn->query($query);

            while($row = $result->fetch_assoc()){
                    ?>
                    <tr>
                        <td><?php echo $row['name']?></td>
                        <td><?php echo $row['email']?></td>
                        <td><?php echo $row['password']?></td>
                        <td><img src="<?php echo $row['image']?>" height="50px" width="50px" alt=""></td>
                        <td><a href="update.php?id=<?php echo $row['id']?>">Update</a></td>
                        <td><a href="?id=<?php echo $row['id']?>">Delete</a></td>
                    </tr>
                    <?php


            }?>

       
    </table>



</body>
</html>