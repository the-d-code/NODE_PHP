const SecretKey = "N2nA1aY0yA1aN2nC0cH0hA1aB0bH1hA2aD3dI4iY5yA6a7";
const LocalUrl = "mongodb://localhost:27017/exam";
const Port = 8000;
const Host = "localhost";


module.exports = {
  SecretKey,
  LocalUrl,
  Port,
  Host,
};