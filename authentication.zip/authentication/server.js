const express = require("express");
const app = express();
const mongoose = require("mongoose");
const cors = require("cors");
const userRoutes = require("./Apis/routes/userRoutes");
const roleRoutes = require("./Apis/routes/roleRoutes");
const authRoutes = require("./Apis/routes/authRoutes");

mongoose
  .connect("mongodb://localhost:27017/nayan", {
    family: 4,
  })
  .then(() => {
    console.log("Database Connected....");
  })
  .catch((err) => {
    console.log("Connection failed because of: ", err);
  });

app.use(cors());

app.use(express.json());

app.use("/api/user", userRoutes);
app.use("/api/role", roleRoutes);
app.use("/api/auth", authRoutes);

app.listen(8000, () => {
  console.log(`Server running on http://localhost:8000/`);
});
