const userSchema = require("../model/userModel");
const roleSchema = require("../model/roleModel");
const bcrypt = require("bcrypt");

module.exports = {
  getUsers: async (req, res) => {
    const users = await userSchema.find();
    if (users.length === 0) {
      return res.status(400).json({
        message: "No users found..",
      });
    }
    res.status(200).json({
      users,
    });
  },

  addUser: async (req, res) => {
    const { username, password, roleId } = req.body;
    const role = await roleSchema.findById(roleId);
    if (!role) {
      return res.status(400).json({
        message: "Role not found...",
      });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new userSchema({
      username,
      password: hashedPassword,
      role: role.toObject(),
    });
    const savedUser = await user.save();
    if (!savedUser) {
      return res.status(400).json({
        message: "User not created...",
      });
    }
    res.status(201).json({
      message: "User created successfully...",
      data: savedUser,
    });
  },

  updateUser: async (req, res) => {
    const userId = req.params.id;
    const { username, password, roleId } = req.body;
    const role = await roleSchema.findById(roleId);
    if (!role) {
      return res.status(400).json({
        message: "Role not found...",
      });
    }
    const hashedPassword = await bcrypt.hash(password, 10);

    const result = await userSchema.findOneAndUpdate(
      { _id: userId },
      { username, password: hashedPassword, role: role.toObject() },
      { new: true }
    );
    if (!result) {
      return res.status(400).json({
        message: "User not updated...",
      });
    }
    res.status(200).json({
      message: "User updated successfully...",
      data: result,
    });
  },

  deleteUser: async (req, res) => {
    const userId = req.params.id;
    const result = await userSchema.deleteOne({ _id: userId });
    if (!result) {
      return res.status(400).json({
        message: "User not deleted...",
      });
    }
    res.status(200).json({
      message: "User deleted successfully...",
      data: result,
      deletedCount: result.deletedCount,
    });
  },
};
