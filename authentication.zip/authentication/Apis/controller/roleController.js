const roleSchema = require("../model/roleModel");

module.exports = {
  getRoles: async (req, res) => {
    const roles = await roleSchema.find();
    if (roles.length === 0) {
      return res.status(404).json({ message: "No roles found..." });
    }
    res.status(200).json({ roles });
  },

  addRole: async (req, res) => {
    const newRole = req.body;
    const role = new roleSchema(newRole);
    const savedRole = await role.save();
    if (!savedRole) {
      return res.status(400).json({ message: "Role not created..." });
    }
    res
      .status(201)
      .json({ message: "Role created successfully...", data: savedRole });
  },

  updateRole: async (req, res) => {
    const roleId = req.params.id;
    const updatedRole = req.body;
    const result = await roleSchema.findOneAndUpdate(
      { _id: roleId },
      updatedRole,
      { new: true }
    );
    if (!result) {
      return res.status(400).json({ message: "Role not updated..." });
    }
    res.status(200).json({
      message: "Role updated successfully....",
      data: result,
    });
  },

  deleteRole: async (req, res) => {
    const roleId = req.params.id;
    const result = await roleSchema.deleteOne({ _id: roleId });
    if (!result) {
      return res.status(400).json({ message: "Role not delete" });
    }
    res.status(200).json({ message: "Role deleted successfully....", deletedCount: result.deletedCount})
  },
};
