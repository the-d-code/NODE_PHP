const studentModel = require("../model//studentModel");

module.exports = {
  addStudent: async (req, res) => {
    try {
    } catch (error) {}
  },
  getStudents: async (req, res) => {
    try {
      const studentData = await studentModel.find();
      if (studentData.length === 0) {
        res.status(404).json({
          status: "error",
          message: "Student not found",
          payload: {},
        });
      } else {
        res.status(200).json({
          status: "success",
          message: "Student get successfully",
          payload: { student: studentData },
        });
      }
    } catch (error) {
      res.status(400).json({
        status: "error",
        message: "Something went to wrong",
        payload: {},
      });
    }
  },
  getStudentById: async (req, res) => {
    try {
    } catch (error) {
      res.status(400).json({
        status: "error",
        message: "Something went to wrong",
        payload: {},
      });
    }
  },
  updateStudent: async (req, res) => {
    try {
    } catch (error) {
      res.status(400).json({
        status: "error",
        message: "Something went to wrong",
        payload: {},
      });
    }
  },
  deleteStudent: async (req, res) => {
    try {
    } catch (error) {
      res.status(400).json({
        status: "error",
        message: "Something went to wrong",
        payload: {},
      });
    }
  },
};
