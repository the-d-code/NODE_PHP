const userSchema = require("../model/userModel");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const config = require("../../config/config");

module.exports = {
  login: async (req, res) => {
    try {
      const { username, password } = req.body;
      const user = await userSchema.findOne({ username });

      if (!user) {
        return res.status(400).json({
          message: "User not found...",
        });
      }

      let isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.status(400).json({
          message: "Password is incorrect...",
        });
      }

      const token = jwt.sign(
        {
          userId: user._id,
          username: user.username,
          role: user.role,
        },
        config.secretKey,
        { expiresIn: "1h" }
      );
      res.status(200).json({
        data: {
          message: "Login success...",
          token: token,
          user: user,
          success: true,
        },
      });
    } catch (err) {
      console.log(err);
      res.status(500).json({
        message: "Internal server error...",
      });
    }
  },
};
