const express = require("express");
const router = express.Router();
const userController = require("../controller/userController");
const authMiddleware = require("../middleware/authMiddleware");
const authorizeMiddleware = require("../middleware/authorizeMiddleware");

router.get("/", userController.getUsers);
router.post("/", userController.addUser);
router.put("/:id", userController.updateUser);
router.delete("/:id", userController.deleteUser);
router.get(
  "/allUsers",
  authMiddleware,
  authorizeMiddleware(["admin"]),
  userController.getUsers
);

module.exports = router;
