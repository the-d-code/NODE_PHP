const mongoose = require("mongoose");

const studentSchems = new mongoose.Schema({
  firstName: String,
  lastName: String,
  user: Object,
});

module.exports = mongoose.model("students", studentSchems);
