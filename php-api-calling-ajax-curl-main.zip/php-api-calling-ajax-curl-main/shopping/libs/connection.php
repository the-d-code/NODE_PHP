<?php
session_start();
$conn=mysqli_connect('localhost','root','','oswd') or die (mysql_error());
?>